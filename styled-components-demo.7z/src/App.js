import React from 'react';
import styled, { keyframes }from 'styled-components';
import './App.css';

const Mydiv = styled.div`
 display:flex;
 justify-content:center;
 height: 100%;
`

const ListItem = styled.a`
color: #fff;
text-decoration: none;
padding: 7px 25px;
display: inline-block;
`
const NavBlock = styled.nav`
float: right;
color:white;
`

const ContainerBlock = styled.div`
width: 100%;
margin: 0 auto;
`
const Hearderline = styled.h1`
text-align:center;
font-size:30px;
font-weight:bold;
color:red;
top: 44px;
position: relative;
`

const BlockMenu= styled(Hearderline)`
font-size:20px;
font-weight:normal;
color:black;
padding: 16px;
`
const HearderBlock = styled.header`
width: 100%;
position: fixed;        
background: #333;
padding: 10px 0;
color: #fff;
top:0px;
z-index:1;`

const FooterBlock = styled.footer`
width: 100%;
position: fixed;        
background: #333;
padding: 10px 0;
color: #fff;
bottom:0px;
`
const ButtonBlock =styled.div`
width: auto;
margin: 49px 445px;
`

const Button = styled.button`
  background: ${props => props.sonal12121 ? "#B53737" : "#228B22"};
  color: ${props => props.primary ? "#fff" : "#212529"};
  font-size: 1em;
  margin: 1em;
  padding: 0.25em 1em;
  border-radius: 3px;
  cursor:pointer;
  font-size:18px;
  width: 113px;
  
  ::before {
    content: '🚀';
  }

  :hover {
    color: red;
  }
 `

// Create the keyframes

const movingBlock = keyframes`
  { 
    0%   {left: 0px;}
    100% {left: 400px;}
  }
`;
// Here we create a component that will rotate everything we pass in over two seconds
const MovingBlock = styled.div`
  display: inline-block;
  animation: ${movingBlock} 2s infinite;
  padding: 2rem 1rem;
  font-size: 1.2rem;
  position :relative;
  width: 100px;
  height: 100px;
  background: red;
`;



function App() {
  return (
   <Mydiv>

       <HearderBlock>
           <ContainerBlock>
               <NavBlock>
                    <ListItem>Styled Components</ListItem>
                    <ListItem>Home</ListItem>
                    <ListItem>about</ListItem>
                    <ListItem> Help</ListItem>
               </NavBlock>
           </ContainerBlock>
        </HearderBlock>
        <ContainerBlock>
            {/* Extending Styles */}
            <Hearderline>Welcome to Styled Components with react </Hearderline>
            <BlockMenu>styled-components is the result of wondering how we could enhance CSS for styling React component systems. By focusing on a single use case we managed to optimize the experience for developers as well as the output for end users.</BlockMenu>
            
            {/* based on props */}
            {/* Pseudoelements, pseudoselectors */}
            <ButtonBlock>
                <Button><span>&#9786;</span>Play</Button>
                <Button sonal12121><span>&#9786;</span>Stop</Button>
            </ButtonBlock>
          
           
            <MovingBlock>hi i m going </MovingBlock>
        </ContainerBlock>
        
        <FooterBlock>
             <ContainerBlock>Sonal @copy right </ContainerBlock>
        </FooterBlock>
       
   </Mydiv>
  );
}

export default App;
