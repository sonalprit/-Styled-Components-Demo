import React from 'react';
import {Prompt} from 'react-router-dom';

class SignInForm extends React.Component {
    constructor(props){
        super(props);
        this.state={
            firstName :'',
            lastName :'',
            valid:false
        };

    }
    
    render(){
        let imgStyle = {
        marginTop: 50,
        width: 500,
        textAlign: 'center',
        marginLeft:20,
        marginRight:20
        };
    return(
        <div>
            <Prompt when={ this.state.valid !== true}
                message="leaving this page u lost ur data"/>
            <br/>
            <h1>Sign In Form </h1><br/>
            <form horizatal={true} inline={true}>
                <input style={imgStyle} 
                type="text"
                value={this.state.firstName}
                placeholder="Enter your First Name"
                onChange={this.onHandleFirstName} required
                />
                <input style={imgStyle}  
                type="text"
                value={this.state.lastName}
                placeholder="Enter the Last Name"
                onChange={this.onHandleLastName}
                />
                <button type="submit" onClick={this.onSubmit}>Submit</button>

            </form>
            
           
        </div>
    );
}

onSubmit = ()=> {
    if(this.state.firstName===''|| this.state.lastName===''){
        this.setState({
            valid:false
        })
    }else{
        this.setState({
            valid:true
        })
        alert(`your name ${this.state.firstName} ${this.state.lastName}`)
    }
}
onHandleFirstName= (e)=>{
    this.setState({
        firstName: e.target.value
    });

};
onHandleLastName= (e)=>{
    this.setState({
        lastName:e.target.value
    });
};

}


export default SignInForm;
