import React from 'react';
import {NavLink} from 'react-router-dom';

// const Header = () => {
//      let imgStyle = {
//         marginTop: 50,
//         textAlign: 'center',
//         marginLeft:20,
//         marginRight:20
//     };

//     return(
//         <div className= "header">
//             <NavLink to='/' activeClassName='activeNavLink' className="navlink" style={imgStyle} exact>Home</NavLink>
//             <NavLink to='/about' activeClassName='activeNavLink' className="navlink" style={imgStyle}>About</NavLink>
//             <NavLink to='/help' activeClassName='activeNavLink' className="navlink" style={imgStyle}>Help</NavLink>
//             <NavLink to='/Prompt' activeClassName='activeNavLink' className="navlink" style={imgStyle}>Prompt</NavLink>
//             <NavLink to='/PropsViwer' activeClassName='activeNavLink' className="navlink" style={imgStyle}>PropsViwer</NavLink>
//             <NavLink to='/PageNotFound' activeClassName='activeNavLink' className="navlink" style={imgStyle}>PageNotFound</NavLink>
//         </div>
//     );
// };


// refactoring the above code 

const Header = () => {
    
    const links = [
        {name: 'Prompt',url:'/Prompt'},
        {name: 'PropsViwer',url:'/PropsViwer'},
        {name: 'PageNotFound',url:'/PageNotFound'},
        {name: 'Color',url:'/Color'},
        {name: 'Logging',url:'/Logging'},
        {name: 'Private',url:'/Private'}
    ];

    let imgStyle = {
            marginTop: 50,
            textAlign: 'center',
            marginLeft:20,
            marginRight:20,
            marginBottom: 50,
           
        }
    let linksComponents = links.map((link,index) => {
        
        return(
            <div>
                <li key={index} className={'nav-header'}>
                <NavLink activeClassName='activeNavLink' className="navlink" style={imgStyle} 
                        to={link.url} exact>{link.name}
                </NavLink>
                </li>
            </div>
            
        )
    });
     return(
            <div className="Header">
                 <ul>
                    <li className='nav-header'><NavLink className={'navLink'} activeClassName={'activeNavLink'} 
                         to='/' style={imgStyle} exact>Home</NavLink>
                    </li>
                {linksComponents}
                </ul>
            </div>
        )

};

export default Header;