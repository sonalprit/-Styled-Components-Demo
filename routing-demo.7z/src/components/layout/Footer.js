import React from 'react';



const Footer = () => {

    return(
        <div className= "Footer">
            <h6>@SonalSonawane.com</h6>

        </div>
    );
};

export default Footer;