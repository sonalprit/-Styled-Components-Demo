import React from 'react';

const LoggingDefaultMessage = () => {
    return(
        <div>
            <p> welcome to custome link </p>
        </div>
    )
}

export default LoggingDefaultMessage;