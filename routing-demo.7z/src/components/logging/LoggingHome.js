import React from 'react';
import {Route} from 'react-router-dom';
import LoggingDefaultMessage from './LoggingDefaultMessage'
import LoggingLink from './LoggingLink';
import LogginRoute from './LoggingRoute'
import Lorem from './Lorem';


const LoggingHome = ({match}) => {
     console.log(match.url);
     const LoggingStyle={
        marginLeft:20,
    }
    return(
        <div style={LoggingStyle}>
            <br/>
            <h1>Logging Page</h1>
            <h5>
                <LoggingLink to={`${match.url}/Lorem/7fd2a0f4-29ea-4650-803a-67418b597090`}>Link 1 </LoggingLink>
                {'    |    '}
                <LoggingLink to={`${match.url}/Lorem/1842a9f0-449d-499f-bd19-36106da591fa`}>Link 2 </LoggingLink>
            </h5>

            <LogginRoute path={`${match.url}/Lorem/:eid`} component={Lorem} ></LogginRoute>
            <Route path={`${match.url}`} component={LoggingDefaultMessage} exact></Route>
        </div>
    )

}

export default LoggingHome;