import React from 'react';

const Home = () => {

    let imgStyle = {
       width: 500,
       marginLeft:20
    };

    return(
        <div>
           <div>
             <h1  style={imgStyle}>Home</h1>
             <img style={imgStyle} alt="codefile "src='http://www.rd.com/wp-content/uploads/sites/2/2016/04/01-cat-wants-to-tell-you-laptop.jpg' />

           </div>
            
        </div>
       
    );
};

export default Home;