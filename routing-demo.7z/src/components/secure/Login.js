import React from 'react';
import authService from "../../services/authService";
import {Redirect} from "react-router-dom";

class Login extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            email1:'',
            password1:'',
            loggedIn: authService.isAuthenticated(),
            
        };
    }

    render = () => {

        const {target} = this.props.location.state || {target: {pathname: '/Private'}};

        if (this.state.loggedIn) {
            return <Redirect to={target}/>;
        }

        return (
            <div className="container">
                <h1>Sign In</h1>

                <form horizontal={true} inline={true}>
                        <div class="form-group">
                            <label for="InputEmail">Email address</label>
                            <input type="email" 
                            class="form-control" 
                            value={this.state.email1}
                            id="InputEmail" 
                            placeholder="Enter email"
                            onChange={this.onHandleemailChange}  required/>
                        </div>        
                        <div class="form-group">
                            <label for="InputPassword">Password</label>
                            <input type="password" 
                            class="form-control" 
                            value={this.state.password1}
                            id="InputPassword" 
                            placeholder="Password"
                            onChange={this.onHandlepasswordChange} required/>
                        </div>
                        
                        <button  type="submit"  className='btn btn-primary' onClick={this.login}>Sign in</button>
                   
                </form>
            </div>
        );
    };
    onHandleemailChange= (e)=>{
        this.setState({
            email1: e.target.value
        });

    };
    onHandlepasswordChange= (e)=>{
        this.setState({
            password1:e.target.value
        });
    };



    login = () => {
        authService.signIn((e) => {
            if((this.state.email  === ' ') || (this.state.password === ''))
            {
                alert('Enter the Email Id and Password ');
            }else{
                this.setState({
                loggedIn: authService.isAuthenticated()
               
            })
            }
            
        })
    };
}

export default Login;