import React from 'react';

const PropsViwer = ({match, location}) =>{
    const propsviwerStyle={
        marginLeft:20,
        marginTop:20
    }
    return(
        <div style={propsviwerStyle}>
           <div>
               <br/>
                <h4>{match.path}</h4>
                 <h4>{location.key}</h4>
           </div>
           
        </div>
       
    )

}

export default PropsViwer