import React from 'react';

const PropsViwer = ({match, location}) =>{
    return(
        <div>
            <br/>
             <h4>{match.path}</h4>
            <h4>{location.key}</h4>
        </div>
       
    )

}

export default PropsViwer