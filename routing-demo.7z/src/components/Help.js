import React from 'react';

const Help = () => {

    let imgStyle = {
        marginTop: 50,
        width: 500,
        textAlign: 'center'
    };

    return(
        <div>
            <br/>
             <h1>Help</h1>
             <img style={imgStyle} alt="codefile "src='http://www.rd.com/wp-content/uploads/sites/2/2016/04/01-cat-wants-to-tell-you-laptop.jpg' />

        </div>
    );
};

export default Help;