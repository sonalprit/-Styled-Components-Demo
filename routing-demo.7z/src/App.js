import React from 'react';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import Help from './components/Help';
import About from './components/About';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import Home from './components/home';
import SignInForm from './components/Prompt/SignIn-form';
import PropsViwer from './components/PropsViwer'
import PageNotFound from './components/Prompt/PageNotFound';
import ColorSwatch from './components/color/colormatch'


const App = () => {

    return (
        <Router>
            <div>

                <Header/>
                <div className='rightContentContainer'>
                    <Switch>
                        <Route path='/' component={Home} exact={true}/>
                        <Route path='/about' component={About} />
                        <Route path='/help' component={Help} />
                        <Route path='/prompt' component={SignInForm} />
                        <Route path='/PropsViwer' component={PropsViwer} />
                        <Route path='/Color'render={()=>{
                            return <ColorSwatch color="pink" text="Pink"/>
                        }} />
                        <Route component={PageNotFound} />
                        
                    </Switch>
 
                </div>
                <Footer/>
            </div>
        </Router>
        
    );
};


export default App;