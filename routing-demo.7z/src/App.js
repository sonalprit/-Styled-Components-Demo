import React from 'react';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import Home from './components/home';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import SignInForm from './components/Prompt/SignIn-form';
import PropsViwer from './components/PropsViwer'
import PageNotFound from './components/PageNotFound';
import ColorSwatch from './components/color/colormatch'
import LoggingHome from './components/logging/LoggingHome'
import ProtectedHome from './components/secure/ProtectedHome'
import PrivateRoute from './components/secure/PrivateRoute'
import Login from './components/secure/Login';
import Logout from './components/secure/Logout';



const App = () => {

    return (
        <Router>
            <div>

                <Header/>
                <br/>
                <div className='rightContentContainer'>
                    <Switch>
                        <Route path='/' component={Home} exact={true}/>
                        <Route path='/prompt' component={SignInForm} />
                        <Route path='/PropsViwer' component={PropsViwer} />
                        <Route path='/Color'render={()=>{
                            return <ColorSwatch color="pink" text="Pink"/>
                        }} />

                        <Route path='/Logging' component={LoggingHome} />
                        <PrivateRoute path='/Private' component={ProtectedHome} />
                        <Route path='/Login' component={Login} />
                        <Route path='/Logout' component={Logout} />


                        <Route component={PageNotFound} />
                        
                    </Switch>
                </div>
                <Footer/>
            </div>
        </Router>
        
    );
};


export default App;